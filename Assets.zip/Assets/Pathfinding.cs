using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;

public class Pathfinding : MonoBehaviour {

	public Transform seeker, target;
	grid Grid;

	void Awake() {
		Grid = GetComponent<grid> ();
	}

	void Update() {
		FindPathA (seeker.position, target.position);
		FindPathA2(seeker.position, target.position);
		FindPathBFS(seeker.position, target.position);
		FindPathDFS(seeker.position, target.position);
		FindPathUCS(seeker.position, target.position);
	}


	void FindPathA(Vector3 startPos, Vector3 targetPos) {
		Node startNode = Grid.NodeFromWorldPoint(startPos);
		Node targetNode = Grid.NodeFromWorldPoint(targetPos);
		int explored_nodes = 0;
		int fringe_nodes = 0;
		List<Node> openSet = new List<Node>();
		HashSet<Node> closedSet = new HashSet<Node>();
		
		Stopwatch stopwatch  = new Stopwatch();
		stopwatch.Start();

		openSet.Add(startNode);
		fringe_nodes++;

		while (openSet.Count > 0) {
			Node node = openSet[0];
			for (int i = 1; i < openSet.Count; i ++) {
				if (openSet[i].fCost < node.fCost || openSet[i].fCost == node.fCost) {
					if (openSet[i].hCost < node.hCost)
						node = openSet[i];
				}
			}

			openSet.Remove(node);
			explored_nodes++;
			closedSet.Add(node);

			if (node == targetNode) {
				stopwatch.Stop();
				print("A* took : "+stopwatch.ElapsedMilliseconds+" milliseconds");
				print("A* Fringe nodes : "+fringe_nodes);
				print("A* Explored nodes : "+explored_nodes);
				RetracePath(startNode,targetNode,1);
				return;
			}

			foreach (Node neighbour in Grid.GetNeighbours(node)) {
				if (!neighbour.walkable || closedSet.Contains(neighbour)) {
					continue;
				}

				int newCostToNeighbour = node.gCost + GetDistance(node, neighbour);
				if (newCostToNeighbour < neighbour.gCost || !openSet.Contains(neighbour)) {
					neighbour.gCost = newCostToNeighbour;
					neighbour.hCost = GetDistance(neighbour, targetNode);
					neighbour.parent = node;

					if (!openSet.Contains(neighbour)){
						openSet.Add(neighbour);
						fringe_nodes++;
					}
				}
			}
		}
	}
	
	void FindPathA2(Vector3 startPos, Vector3 targetPos) {
		Node startNode = Grid.NodeFromWorldPoint(startPos);
		Node targetNode = Grid.NodeFromWorldPoint(targetPos);
		int explored_nodes = 0;
		int fringe_nodes = 0;
		List<Node> openSet = new List<Node>();
		HashSet<Node> closedSet = new HashSet<Node>();

		Stopwatch stopwatch  = new Stopwatch();
		stopwatch.Start();

		openSet.Add(startNode);
		fringe_nodes++;
		while (openSet.Count > 0) {
			Node node = openSet[0];
			for (int i = 1; i < openSet.Count; i ++) {
				if (openSet[i].fCost2 < node.fCost2 || openSet[i].fCost2 == node.fCost2) {
						node = openSet[i];
				}
			}

			openSet.Remove(node);
			explored_nodes++;
			closedSet.Add(node);

			if (node == targetNode) {
				stopwatch.Stop();
				print("A* with different heuristic Time : "+stopwatch.ElapsedMilliseconds+" milliseconds");
				print("A* with different heuristic Fringe nodes : "+fringe_nodes);
				print("A* with different heuristic Explored nodes : "+explored_nodes);
				RetracePath(startNode,targetNode,5);
				return;
			}

			foreach (Node neighbour in Grid.GetNeighbours(node)) {
				if (!neighbour.walkable || closedSet.Contains(neighbour)) {
					continue;
				}

				int newCostToNeighbour = node.gCost + GetDistance(node, neighbour,1);
				if (newCostToNeighbour < neighbour.gCost || !openSet.Contains(neighbour)) {
					neighbour.gCost = newCostToNeighbour;
					neighbour.hCost = GetDistance(neighbour, targetNode,1);;
					neighbour.parent = node;

					if (!openSet.Contains(neighbour))
						openSet.Add(neighbour);
						fringe_nodes++;
				}
			}
		}
	}	


	void FindPathBFS(Vector3 startPos, Vector3 targetPos){
		Node startNode = Grid.NodeFromWorldPoint(startPos);
		Node targetNode = Grid.NodeFromWorldPoint(targetPos);
		int explored_nodes=0;
		int fringe_nodes=0;
		Queue<Node> queue = new Queue<Node>();
		HashSet<Node> visited = new HashSet<Node>();

		Stopwatch stopwatch  = new Stopwatch();
		stopwatch.Start();

		queue.Enqueue(startNode); //make sure to add at the begining
		fringe_nodes++;

		while(queue.Count > 0){
			Node current_node = queue.Dequeue();
			explored_nodes++;
			if(current_node == targetNode){
				stopwatch.Stop();
				print("BFS Time : "+stopwatch.ElapsedMilliseconds+" milliseconds");
				print("BFS fringe nodes : "+fringe_nodes);
				print("BFS explored nodes : "+explored_nodes);
				RetracePath(startNode, targetNode,2);
				return;
			}
			if(!visited.Contains(current_node)){
				visited.Add(current_node);
				foreach (Node neighbour in Grid.GetNeighbours(current_node)) {
					if (!neighbour.walkable || visited.Contains(neighbour))continue;
					
					neighbour.parent = current_node;
					queue.Enqueue(neighbour);
					fringe_nodes++;
				
				}
			}
			

		}
	}


	void FindPathDFS(Vector3 startPos, Vector3 targetPos){
		Node startNode = Grid.NodeFromWorldPoint(startPos);
		Node targetNode = Grid.NodeFromWorldPoint(targetPos);
		int fringe_nodes=0;
		int explored_nodes=0;
		Stack<Node> StackDFS = new Stack<Node>();
		HashSet<Node> visited = new HashSet<Node>();


		Stopwatch stopwatch  = new Stopwatch();
		stopwatch.Start();

		StackDFS.Push(startNode);
		fringe_nodes++;

		while (StackDFS.Count > 0){
			Node current_node = StackDFS.Pop();
			explored_nodes++;
			if (current_node == targetNode){
				stopwatch.Stop();
				print("DFS Time : "+stopwatch.ElapsedMilliseconds+" milliseconds");
				print("DFS fringe nodes : "+fringe_nodes);
				print("DFS explored nodes : "+explored_nodes);
				RetracePath(startNode, targetNode,3);
				return;
			}
			
			if(!visited.Contains(current_node)){
				visited.Add(current_node);
				foreach (Node neighbour in Grid.GetNeighbours(current_node)){
					if (!neighbour.walkable || visited.Contains(neighbour))continue;
					neighbour.parent = current_node;
					StackDFS.Push(neighbour);
					fringe_nodes++;
				
				}
			}

			
		}
	}


	void FindPathUCS(Vector3 startPos, Vector3 targetPos){
		Node startNode = Grid.NodeFromWorldPoint(startPos);
		Node targetNode = Grid.NodeFromWorldPoint(targetPos);
		int fringe_nodes=0;
		int explored_nodes=0;
		List<Node> queue = new List<Node>();
		HashSet<Node> visited = new HashSet<Node>();

		Stopwatch stopwatch  = new Stopwatch();
		stopwatch.Start();

		queue.Add(startNode);
		fringe_nodes++;

		while (queue.Count > 0)
		{
			Node node = queue[0];
			for (int i = 1; i < queue.Count; i++){
				if (queue[i].gCost <= node.gCost){
					node = queue[i];
				}
			}

			queue.Remove(node);
			explored_nodes++;
			visited.Add(node);

			if (node == targetNode){
				stopwatch.Stop();
				print("UCS Time : "+stopwatch.ElapsedMilliseconds+" milliseconds");
				print("UCS fringe nodes : "+fringe_nodes);
				print("UCS explored nodes : "+explored_nodes);
				RetracePath(startNode, targetNode, 4);
				return;
			}

			foreach (Node neighbor in Grid.GetNeighbours(node)){
				if (!neighbor.walkable || visited.Contains(neighbor))continue;
				
				if (node.gCost < neighbor.gCost || !visited.Contains(neighbor)){
					neighbor.gCost = node.gCost + GetDistance(node, neighbor, 1);
					neighbor.hCost = 0;
					neighbor.parent = node;

					if (!queue.Contains(neighbor))
					queue.Add(neighbor);
					fringe_nodes++;
				}
			}
		}
	}

	


	void RetracePath(Node startNode, Node endNode,int num) {
		List<Node> path = new List<Node>();
		Node currentNode = endNode;

		while (currentNode != startNode) {
			path.Add(currentNode);
			currentNode = currentNode.parent;
		}
		path.Reverse();

		if(num == 1)Grid.AStarpath = path;
		if(num == 2)Grid.BFSpath = path;
		if(num == 3)Grid.DFSpath = path;
		if(num == 4)Grid.UCSpath = path;
		if(num == 5)Grid.AStarpath2 = path;

	}

	int GetDistance(Node nodeA, Node nodeB, int flag = 0) {
		int dstX = Mathf.Abs(nodeA.gridX - nodeB.gridX);
		int dstY = Mathf.Abs(nodeA.gridY - nodeB.gridY);

		if(flag == 1){
			if (dstX > dstY)
				return 10*dstY + 10* (dstX-dstY);
			return 10*dstX + 10 * (dstY-dstX);
		}
		if (dstX > dstY)
			return 14*dstY + 10* (dstX-dstY);
		return 14*dstX + 10 * (dstY-dstX);
	}
}
